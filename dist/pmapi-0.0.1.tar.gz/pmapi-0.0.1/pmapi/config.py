import os
from dotenv import load_dotenv
load_dotenv("/etc/default/pmapi")


class Config:
    alpha = {
        "dir": "/var/www/html/mirrors/alpha",
    }
    beta = {
        "dir": "/var/www/html/mirrors/beta",
    }
    staging = {
        "dir": "/var/www/html/mirrors/staging",
    }
    production = {
        "dir": "/var/www/html/mirrors/production",
    }
    HOSTNAME = os.getenv("HOSTNAME")
    IP = os.getenv("IP")
    STATE = os.getenv("STATE")
    URL = os.getenv("URL")
    TOKEN = os.getenv("TOKEN")
