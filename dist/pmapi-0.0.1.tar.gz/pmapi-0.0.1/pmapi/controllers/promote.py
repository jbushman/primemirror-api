import os
import logging
import requests
from flask import request

from pmapi.config import Config
#from pmapi.services.sign import sign_rpm
#from pmapi.services.sync import sync_repo


def post_promote():
    """
    Promote packages from one repository to another
    Sign packages for the promoted repo
    Copy package to promoted repo
    Update repodata
    Sync repo to mirrors infrastructure
    :return:
    """
    data = request.get_json()
    try:
        logging.info("Promoting: {} from {} repo to {} repo".format(data["package"], data["init_repo"],
                                                                    data["dest_repo"]))
        repodir = Config.data["repo"]["dir"]
        #check if rpm is already in dest repo
        #copy rpm to dest repo if not already there
        #
    except Exception as e:
        response = {
            "status": "failure",
            "message": "Package promotion failed.",
            "exception": str(e)
        }
        return response, 409

