import os
import requests
from flask import request

from pmapi.config import Config


def post_sign():
    data = request.get_json()
    try:
        pass
    except Exception as e:
        response = {
            "status": "failure",
            "message": "POST sign failed.",
            "exception": str(e)
        }
        return response, 409
