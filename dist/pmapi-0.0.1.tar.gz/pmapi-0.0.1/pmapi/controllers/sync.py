import os
import json
from flask import request

from pmapi.config import Config


def get_sync(repo):
    """
    Sync a primemirror repo to the mirrors infrastructure
    :param file:
    :param data:
    :return:
    """
    pass
